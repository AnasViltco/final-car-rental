import React from 'react'

function Specs() {
    return (
        <div>
            
        </div>
    )
}

export default Specs
